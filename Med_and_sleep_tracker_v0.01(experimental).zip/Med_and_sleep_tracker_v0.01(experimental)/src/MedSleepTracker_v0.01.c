#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<math.h>
int main()
{
    double sleep_hours[7];
    double sleep_hours2[2];
    double today_sleep = 0.0;
    double weekly_sleep_average = 0.0;
    double twoday_sleep_average = 0.0;
    double threeday_sleep_average = 0.0;

    double total_sleep = 0.0;
    double average_sleep = 0.0;
    double woke_up_time = 0.0;
    double bed_time = 0.0;
    double revotiril = 0.0;
    double furunitrazepam = 0.0;
    double asenapine = 0.0;
    double quetiapine = 0.0;
    double rexulti = 0.0;
    int date = 0;
    int year = 0;
    int week = 0;
    int sleep_hour = 0;
    int sleep_minute = 0;
    int wokeup_hour = 0;
    int wokeup_minute = 0;

    printf("Enter your woke up time by hour and minute (e.g., 7 30 for 7:30 AM): ");
    scanf("%d %d", &wokeup_hour, &wokeup_minute);
    printf("Enter your bed time by hour and minute (e.g., 22 45 for 10:45 PM): ");
    scanf("%d %d", &sleep_hour, &sleep_minute);
    int sleep_time_in_minutes = sleep_hour * 60 + sleep_minute;
    int wokeup_time_in_minutes = wokeup_hour * 60 + wokeup_minute;
    
    int total = wokeup_time_in_minutes - sleep_time_in_minutes;
    if(total < 0) {
        total += 24 * 60; // Adjust for overnight sleep
    }
    printf("You slept for %d hours and %d minutes.\n", total / 60, total % 60);
    today_sleep = total / 60.0; // Convert to hours for storage and calculations
    
    // Convert hour/minute to decimal times
    woke_up_time = wokeup_hour + wokeup_minute / 60.0;
    bed_time = sleep_hour + sleep_minute / 60.0;    

    printf("Enter the furunitrazepam dose (in mg) : ");
    scanf("%lf", &furunitrazepam);
    printf("Enter the asenapine dose (in mg) : ");
    scanf("%lf", &asenapine);
    printf("Enter the quetiapine dose (in mg) : ");
    scanf("%lf", &quetiapine);
    printf("Enter the rexulti dose (in mg) : ");
    scanf("%lf", &rexulti);

    // Get current date and time
    time_t t = time(NULL);
    struct tm *tm_info = localtime(&t);
    year = tm_info->tm_year + 1900;
    date = tm_info->tm_mday;
    week = tm_info->tm_yday / 7 + 1;


    FILE *file = fopen("MedSleepTracker_data.csv", "a+");
    if(file == NULL)
    {
        printf("Error opening file!");
        return 1;
        getchar(); // Wait for user input before exiting   
    }
    fprintf(file, "year: %d\n", year);
    fprintf(file, "date: %d\n", date);
    fprintf(file, "week: %d\n", week);
    fprintf(file, "woke_up_time: %.2lf\n", woke_up_time);
    fprintf(file, "bed_time: %.2lf\n", bed_time);
    fprintf(file, "today_sleep: %.2lf\n", today_sleep);
    fprintf(file, "furunitrazepam: %.2lf\n", furunitrazepam);
    fprintf(file, "asenapine: %.2lf\n", asenapine);
    fprintf(file, "quetiapine: %.2lf\n", quetiapine);
    fprintf(file, "rexulti: %.2lf\n", rexulti);
    fprintf(file, "-----------------------------\n");

    fclose(file);
    printf("Data saved successfully!\n");
    printf("1.show data\n2.exit\n");
    int choice;
    scanf("%d", &choice);
    if(choice == 1)
    {
        printf("Data is being stored internally.\n");
        getchar();
    }
    else if(choice == 2)
    {
        printf("Exiting the program. Goodbye!\n");
    }
    else
    {
        printf("Invalid choice! Exiting the program.\n");
    }
    getchar(); // Wait for user input before exiting    

    // delete executable after closing everything
    if(remove("a.exe") == 0) {
        printf("Program cleaned up.\n");
    } else {
        // a.exe may not exist, that's fine
    }
    getchar(); // Wait for user input before exiting
    

    return 0;
}  